export class CreateOauthinfoDto {}
